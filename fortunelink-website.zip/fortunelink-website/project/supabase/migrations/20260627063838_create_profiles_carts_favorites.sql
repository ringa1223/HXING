/*
# Full-stack e-commerce setup: profiles, carts, favorites

## Tables Created
- `profiles`: User profile info (display_name, email, is_admin flag). First user to register gets admin.
- `carts`: Shopping cart items per user (product_id integer, quantity). Unique per user+product.
- `favorites`: Favorited product IDs per user. Unique per user+product.

## Helper Functions
- `is_admin()`: SECURITY DEFINER — checks if auth.uid() has is_admin=true. Used in RLS without causing recursion.
- `create_profile(display_name, email)`: SECURITY DEFINER — creates profile, auto-grants admin to first user.
- `get_admin_stats()`: SECURITY DEFINER — returns aggregate stats for admin dashboard (bypasses RLS).

## RLS Policies
- profiles: authenticated users manage own; admin can SELECT all.
- carts: authenticated users manage own; admin can SELECT all.
- favorites: authenticated users manage own; admin can SELECT all.

## Important Notes
1. All user_id columns DEFAULT to auth.uid() — inserts don't need to pass user_id explicitly.
2. is_admin() is SECURITY DEFINER to prevent RLS recursion when checking the profiles table.
3. create_profile() counts total profiles with SECURITY DEFINER to make first user admin.
4. Cart enforces UNIQUE(user_id, product_id); use upsert or check-then-update on the frontend.
5. Favorites enforces UNIQUE(user_id, product_id) to prevent duplicate entries.
*/

-- =====================
-- Tables
-- =====================
CREATE TABLE IF NOT EXISTS profiles (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid        NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text       NOT NULL DEFAULT '',
  email       text        NOT NULL DEFAULT '',
  is_admin    boolean     NOT NULL DEFAULT false,
  created_at  timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

CREATE TABLE IF NOT EXISTS carts (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid        NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id  integer     NOT NULL,
  quantity    integer     NOT NULL DEFAULT 1,
  created_at  timestamptz DEFAULT now(),
  CONSTRAINT carts_qty_positive CHECK (quantity > 0),
  UNIQUE(user_id, product_id)
);

CREATE TABLE IF NOT EXISTS favorites (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid        NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id  integer     NOT NULL,
  created_at  timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

-- =====================
-- Indexes
-- =====================
CREATE INDEX IF NOT EXISTS profiles_user_id_idx  ON profiles(user_id);
CREATE INDEX IF NOT EXISTS carts_user_id_idx     ON carts(user_id);
CREATE INDEX IF NOT EXISTS favorites_user_id_idx ON favorites(user_id);

-- =====================
-- RLS
-- =====================
ALTER TABLE profiles  ENABLE ROW LEVEL SECURITY;
ALTER TABLE carts     ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;

-- =====================
-- Helper functions
-- =====================

-- is_admin(): SECURITY DEFINER so it bypasses RLS when querying profiles (no recursion)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles WHERE user_id = auth.uid() AND is_admin = true
  );
$$;

-- create_profile(): first user gets admin; SECURITY DEFINER to count all profiles
CREATE OR REPLACE FUNCTION public.create_profile(p_display_name text, p_email text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_count integer;
BEGIN
  SELECT COUNT(*) INTO v_count FROM public.profiles;
  INSERT INTO public.profiles (user_id, display_name, email, is_admin)
  VALUES (auth.uid(), p_display_name, p_email, v_count = 0)
  ON CONFLICT (user_id) DO NOTHING;
END;
$$;

-- get_admin_stats(): aggregate counts for admin dashboard
CREATE OR REPLACE FUNCTION public.get_admin_stats()
RETURNS json
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT json_build_object(
    'total_users',         (SELECT COUNT(*)    FROM public.profiles),
    'total_cart_entries',  (SELECT COUNT(*)    FROM public.carts),
    'total_cart_qty',      (SELECT COALESCE(SUM(quantity), 0) FROM public.carts),
    'total_favorites',     (SELECT COUNT(*)    FROM public.favorites)
  );
$$;

-- =====================
-- profiles policies
-- =====================
DROP POLICY IF EXISTS "profiles_select" ON profiles;
CREATE POLICY "profiles_select" ON profiles FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "profiles_insert" ON profiles;
CREATE POLICY "profiles_insert" ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "profiles_update" ON profiles;
CREATE POLICY "profiles_update" ON profiles FOR UPDATE
TO authenticated
USING  (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "profiles_delete" ON profiles;
CREATE POLICY "profiles_delete" ON profiles FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- =====================
-- carts policies
-- =====================
DROP POLICY IF EXISTS "carts_select" ON carts;
CREATE POLICY "carts_select" ON carts FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "carts_insert" ON carts;
CREATE POLICY "carts_insert" ON carts FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "carts_update" ON carts;
CREATE POLICY "carts_update" ON carts FOR UPDATE
TO authenticated
USING  (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "carts_delete" ON carts;
CREATE POLICY "carts_delete" ON carts FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- =====================
-- favorites policies
-- =====================
DROP POLICY IF EXISTS "favorites_select" ON favorites;
CREATE POLICY "favorites_select" ON favorites FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "favorites_insert" ON favorites;
CREATE POLICY "favorites_insert" ON favorites FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "favorites_delete" ON favorites;
CREATE POLICY "favorites_delete" ON favorites FOR DELETE
TO authenticated
USING (auth.uid() = user_id);
