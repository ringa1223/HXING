/*
# Restrict SECURITY DEFINER function execution to authenticated role only

## Problem
Three SECURITY DEFINER functions in public schema were executable by the `anon` role
via the PostgREST REST API (/rest/v1/rpc/...). This is a security risk because:
- `anon` callers (unauthenticated requests) should never invoke SECURITY DEFINER functions.
- By default Postgres grants EXECUTE to PUBLIC (which includes anon).

## Changes
1. Revoke EXECUTE from PUBLIC on all three functions (removes the catch-all default grant).
2. Re-grant EXECUTE explicitly to `authenticated` only, because:
   - `is_admin()` is called internally by RLS policies evaluated under the `authenticated` role.
   - `create_profile()` is called by the frontend after user sign-up (authenticated session).
   - `get_admin_stats()` is called by the admin dashboard (authenticated session).

## Security Result
- `anon` role: no EXECUTE on any of the three functions → REST API calls blocked.
- `authenticated` role: explicit EXECUTE retained → app and RLS policies continue to work.
- `service_role` / postgres superuser: unaffected (superusers bypass privilege checks).
*/

-- Revoke the default PUBLIC grant (covers both anon and authenticated)
REVOKE EXECUTE ON FUNCTION public.is_admin()                          FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.create_profile(text, text)          FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_admin_stats()                   FROM PUBLIC;

-- Re-grant only to authenticated (RLS policies and app code run as this role)
GRANT EXECUTE ON FUNCTION public.is_admin()                           TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_profile(text, text)           TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_admin_stats()                    TO authenticated;
