import { useState, useEffect } from 'react';

import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { FavoritesProvider } from './contexts/FavoritesContext';

import TopBar from './components/TopBar';
import Header from './components/Header';
import CategoryNav from './components/CategoryNav';
import HeroCarousel from './components/HeroCarousel';
import FlashSale from './components/FlashSale';
import ProductSection from './components/ProductSection';
import HotSelling from './components/HotSelling';
import BrandShowcase from './components/BrandShowcase';
import ServiceAdvantages from './components/ServiceAdvantages';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import ProductModal from './components/ProductModal';
import AuthModal from './components/AuthModal';
import CartDrawer from './components/CartDrawer';
import AdminPage from './components/AdminPage';
import { Product } from './data/products';

const sections = [
  { id: 'thoi-trang', title: 'Thời trang', emoji: '👕', accent: '#F57C00' },
  { id: 'dien-tu', title: 'Điện tử', emoji: '📱', accent: '#1565C0' },
  { id: 'thuc-pham', title: 'Thực phẩm', emoji: '🛒', accent: '#2E7D32' },
  { id: 'gia-dung', title: 'Gia dụng', emoji: '🏠', accent: '#C62828' },
  { id: 'me-be', title: 'Mẹ & bé', emoji: '👶', accent: '#7B1FA2' },
];

function AppInner() {
  const [scrolled, setScrolled] = useState(false);
  const [page, setPage] = useState<'main' | 'admin'>(() =>
    window.location.pathname.startsWith('/admin') ? 'admin' : 'main'
  );
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [cartOpen, setCartOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onPop = () => {
      setPage(window.location.pathname.startsWith('/admin') ? 'admin' : 'main');
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const navigateTo = (path: string) => {
    window.history.pushState(null, '', path);
    setPage(path.startsWith('/admin') ? 'admin' : 'main');
    window.scrollTo(0, 0);
  };

  const openAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setAuthOpen(true);
  };

  if (page === 'admin') {
    return <AdminPage onBack={() => navigateTo('/')} />;
  }

  return (
    <div className="page-load min-h-screen" style={{ background: '#F5F7FA' }}>
      <TopBar />
      <Header
        scrolled={scrolled}
        onOpenAuth={openAuth}
        onOpenCart={() => setCartOpen(true)}
        onNavigateAdmin={() => navigateTo('/admin')}
      />
      <CategoryNav />

      <main>
        <HeroCarousel />
        <FlashSale />
        {sections.map((s) => (
          <ProductSection
            key={s.id}
            categoryId={s.id}
            title={s.title}
            emoji={s.emoji}
            accentColor={s.accent}
            onProductClick={setSelectedProduct}
          />
        ))}
        <HotSelling onProductClick={setSelectedProduct} />
        <BrandShowcase />
        <ServiceAdvantages />
      </main>

      <Footer />
      <ScrollToTop />

      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenAuth={openAuth}
      />

      {authOpen && (
        <AuthModal
          mode={authMode}
          onClose={() => setAuthOpen(false)}
          onSwitchMode={(m) => setAuthMode(m)}
          onSuccess={() => setCartOpen(true)}
        />
      )}

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onOpenAuth={() => openAuth('login')}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <FavoritesProvider>
          <AppInner />
        </FavoritesProvider>
      </CartProvider>
    </AuthProvider>
  );
}
