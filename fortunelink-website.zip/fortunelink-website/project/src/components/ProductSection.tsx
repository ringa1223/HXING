import { ChevronRight } from 'lucide-react';
import { Product, products } from '../data/products';
import ProductCard from './ProductCard';

interface ProductSectionProps {
  categoryId: string;
  title: string;
  emoji: string;
  accentColor: string;
  onProductClick: (product: Product) => void;
}

export default function ProductSection({ categoryId, title, emoji, accentColor, onProductClick }: ProductSectionProps) {
  const items = products.filter((p) => p.category === categoryId).slice(0, 8);

  return (
    <section id={categoryId} className="py-6 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div
              className="w-1 h-7 rounded-full"
              style={{ background: accentColor }}
            />
            <span className="text-2xl">{emoji}</span>
            <h2 className="text-xl font-black text-gray-900">{title}</h2>
          </div>
          <a
            href={`#${categoryId}`}
            className="flex items-center gap-1 text-sm font-medium transition-colors hover:opacity-80"
            style={{ color: accentColor }}
          >
            Xem tất cả <ChevronRight size={16} />
          </a>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-3">
          {items.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onClick={onProductClick}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
