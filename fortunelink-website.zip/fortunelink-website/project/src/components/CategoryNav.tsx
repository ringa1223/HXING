import { categoryList } from '../data/products';

export default function CategoryNav() {
  return (
    <nav className="bg-white border-b border-gray-100 sticky top-[57px] z-40">
      <div className="max-w-7xl mx-auto px-2">
        <div className="flex items-center overflow-x-auto scrollbar-none gap-1 py-1">
          {categoryList.map((cat) => (
            <a
              key={cat.id}
              href={`#${cat.id}`}
              className="cat-nav-item flex flex-col items-center gap-0.5 px-3 py-2 flex-shrink-0 border-b-2 border-transparent rounded-t text-gray-600 hover:text-primary hover:border-primary transition-all text-center"
              style={{ minWidth: '72px' }}
            >
              <span className="text-xl">{cat.emoji}</span>
              <span className="text-[11px] font-medium whitespace-nowrap leading-tight">{cat.label}</span>
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}
