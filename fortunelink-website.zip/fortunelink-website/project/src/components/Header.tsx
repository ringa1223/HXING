import { useState } from 'react';
import { Search, ShoppingCart, Heart, User, Menu, X, LogOut, Crown } from 'lucide-react';
import { categoryList } from '../data/products';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useFavorites } from '../contexts/FavoritesContext';

interface HeaderProps {
  scrolled: boolean;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onOpenCart: () => void;
  onNavigateAdmin: () => void;
}

export default function Header({ scrolled, onOpenAuth, onOpenCart, onNavigateAdmin }: HeaderProps) {
  const { user, profile, isAdmin, signOut } = useAuth();
  const { cartCount } = useCart();
  const { favoriteIds } = useFavorites();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const favCount = favoriteIds.size;

  return (
    <header
      className={`sticky top-0 z-50 bg-white transition-shadow duration-300 ${
        scrolled ? 'header-shadow' : 'shadow-sm'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center gap-3 md:gap-6">
          {/* Logo */}
          <a href="#home" className="flex-shrink-0">
            <div className="flex flex-col leading-none">
              <span className="text-2xl font-black tracking-tight" style={{ color: '#F57C00' }}>
                FORTUNE<span style={{ color: '#0D2B4A' }}>LINK</span>
              </span>
              <span className="text-[9px] text-gray-400 font-medium tracking-widest uppercase hidden sm:block">
                CÔNG TY TNHH XUẤT NHẬP KHẨU
              </span>
            </div>
          </a>

          {/* Search */}
          <div className="flex-1 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm sản phẩm..."
              className="w-full border-2 rounded-full py-2 pl-4 pr-12 text-sm focus:border-primary transition-colors"
              style={{ borderColor: searchQuery ? '#F57C00' : '#E5E7EB' }}
            />
            <button
              className="absolute right-1 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-90"
              style={{ background: '#F57C00' }}
            >
              <Search size={16} />
            </button>
          </div>

          {/* Icons */}
          <div className="flex items-center gap-1 flex-shrink-0">
            {/* User / Auth */}
            {user ? (
              <div className="relative hidden md:block">
                <button
                  onClick={() => setUserMenuOpen((v) => !v)}
                  className="flex flex-col items-center p-2 hover:text-orange-500 transition-colors group"
                >
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold"
                    style={{ background: '#0D2B4A' }}
                  >
                    {(profile?.display_name || profile?.email || 'U').charAt(0).toUpperCase()}
                  </div>
                  <span className="text-[10px] text-gray-500 mt-0.5 hidden lg:block max-w-16 truncate">
                    {profile?.display_name || 'Tôi'}
                  </span>
                </button>
                {userMenuOpen && (
                  <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-xl shadow-lg border py-1 z-50">
                    <div className="px-4 py-2 border-b">
                      <p className="text-sm font-semibold text-gray-800 truncate">{profile?.display_name}</p>
                      <p className="text-xs text-gray-400 truncate">{profile?.email}</p>
                    </div>
                    {isAdmin && (
                      <button
                        onClick={() => { setUserMenuOpen(false); onNavigateAdmin(); }}
                        className="w-full flex items-center gap-2 px-4 py-2 text-sm text-orange-600 hover:bg-orange-50 transition-colors"
                      >
                        <Crown size={14} />
                        Admin Dashboard
                      </button>
                    )}
                    <button
                      onClick={() => { setUserMenuOpen(false); signOut(); }}
                      className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50 transition-colors"
                    >
                      <LogOut size={14} />
                      Đăng xuất
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => onOpenAuth('login')}
                className="hidden md:flex flex-col items-center p-2 hover:text-orange-500 transition-colors group"
              >
                <User size={22} className="text-gray-600 group-hover:text-orange-500" />
                <span className="text-[10px] text-gray-500 mt-0.5 hidden lg:block">Đăng nhập</span>
              </button>
            )}

            {/* Favorites */}
            <button
              onClick={() => user ? undefined : onOpenAuth('login')}
              className="hidden md:flex flex-col items-center p-2 relative hover:text-orange-500 transition-colors group"
            >
              <Heart
                size={22}
                className={favCount > 0 ? 'text-red-500' : 'text-gray-600 group-hover:text-orange-500'}
                fill={favCount > 0 ? 'currentColor' : 'none'}
              />
              {favCount > 0 && (
                <span
                  className="absolute -top-0.5 right-0.5 w-4 h-4 rounded-full text-white text-[9px] font-bold flex items-center justify-center"
                  style={{ background: '#E53935' }}
                >
                  {favCount}
                </span>
              )}
              <span className="text-[10px] text-gray-500 mt-0.5 hidden lg:block">Yêu thích</span>
            </button>

            {/* Cart */}
            <button
              onClick={user ? onOpenCart : () => onOpenAuth('login')}
              className="flex flex-col items-center p-2 relative"
            >
              <ShoppingCart size={22} className="text-gray-700" />
              {cartCount > 0 && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-5 h-5 rounded-full text-white text-[10px] font-bold flex items-center justify-center"
                  style={{ background: '#E53935' }}
                >
                  {cartCount}
                </span>
              )}
              <span className="text-[10px] text-gray-500 mt-0.5 hidden lg:block">Giỏ hàng</span>
            </button>

            {/* Mobile menu toggle */}
            <button
              className="md:hidden p-2 text-gray-700"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile nav */}
      <div className={`mobile-menu md:hidden bg-white border-t ${mobileOpen ? 'open' : 'closed'}`}>
        <div className="px-4 py-3">
          {user ? (
            <div className="flex items-center justify-between mb-3 pb-3 border-b">
              <div>
                <p className="text-sm font-semibold text-gray-800">{profile?.display_name}</p>
                <p className="text-xs text-gray-400">{profile?.email}</p>
              </div>
              <div className="flex gap-2">
                {isAdmin && (
                  <button
                    onClick={() => { setMobileOpen(false); onNavigateAdmin(); }}
                    className="text-xs text-orange-600 font-semibold px-3 py-1.5 rounded-lg bg-orange-50"
                  >
                    Admin
                  </button>
                )}
                <button
                  onClick={() => { setMobileOpen(false); signOut(); }}
                  className="text-xs text-red-500 font-semibold px-3 py-1.5 rounded-lg bg-red-50"
                >
                  Đăng xuất
                </button>
              </div>
            </div>
          ) : (
            <div className="flex gap-2 mb-3 pb-3 border-b">
              <button
                onClick={() => { setMobileOpen(false); onOpenAuth('login'); }}
                className="flex-1 py-2 text-sm font-semibold rounded-xl border"
                style={{ borderColor: '#F57C00', color: '#F57C00' }}
              >
                Đăng nhập
              </button>
              <button
                onClick={() => { setMobileOpen(false); onOpenAuth('register'); }}
                className="flex-1 py-2 text-sm font-semibold rounded-xl text-white"
                style={{ background: '#F57C00' }}
              >
                Đăng ký
              </button>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            {categoryList.map((cat) => (
              <a
                key={cat.id}
                href={`#${cat.id}`}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-orange-50 text-sm text-gray-700 transition-colors"
              >
                <span className="text-lg">{cat.emoji}</span>
                <span>{cat.label}</span>
              </a>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
