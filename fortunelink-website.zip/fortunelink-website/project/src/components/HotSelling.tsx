import { ChevronRight } from 'lucide-react';
import { Product, products, hotSellingIds } from '../data/products';
import ProductCard from './ProductCard';

interface HotSellingProps {
  onProductClick: (product: Product) => void;
}

export default function HotSelling({ onProductClick }: HotSellingProps) {
  const hotProducts = hotSellingIds.map((id) => products.find((p) => p.id === id)).filter(Boolean) as typeof products;

  return (
    <section className="py-6 px-4">
      <div className="max-w-7xl mx-auto">
        <div
          className="rounded-2xl p-5"
          style={{ background: 'linear-gradient(135deg, #0D2B4A 0%, #1A3A5C 100%)' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🏆</span>
              <div>
                <h2 className="text-xl font-black text-white">Sản phẩm bán chạy</h2>
                <p className="text-white/60 text-xs">Được khách hàng tin tưởng nhất</p>
              </div>
            </div>
            <a
              href="#home"
              className="flex items-center gap-1 text-sm font-medium transition-opacity hover:opacity-80"
              style={{ color: '#FFB74D' }}
            >
              Xem tất cả <ChevronRight size={16} />
            </a>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {hotProducts.map((product) => (
              <div key={product.id} className="relative">
                <div
                  className="absolute -top-2 -left-1 z-10 text-[10px] font-black text-white px-2 py-0.5 rounded-full flex items-center gap-0.5"
                  style={{ background: '#E53935' }}
                >
                  🔥 Bán chạy
                </div>
                <ProductCard product={product} showBadge={false} onClick={onProductClick} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
