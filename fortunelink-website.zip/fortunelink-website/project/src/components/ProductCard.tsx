import { Heart, ShoppingCart, Star } from 'lucide-react';
import { Product, formatPrice, discountPercent } from '../data/products';
import { useFavorites } from '../contexts/FavoritesContext';

interface ProductCardProps {
  product: Product;
  showBadge?: boolean;
  onClick?: (product: Product) => void;
}

export default function ProductCard({ product, showBadge = true, onClick }: ProductCardProps) {
  const disc = discountPercent(product.price, product.originalPrice);
  const { isFavorited, toggleFavorite } = useFavorites();
  const favorited = isFavorited(product.id);

  return (
    <div
      className="bg-white rounded-xl overflow-hidden card-lift shadow-card cursor-pointer group relative"
      onClick={() => onClick?.(product)}
    >
      {/* Image */}
      <div
        className="h-40 relative overflow-hidden"
        style={{ background: product.bgColor }}
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          onError={(e) => {
            const t = e.currentTarget;
            t.style.display = 'none';
            const fb = t.nextElementSibling as HTMLElement | null;
            if (fb) fb.style.display = 'flex';
          }}
        />
        <span className="text-6xl absolute inset-0 hidden items-center justify-center">
          {product.emoji}
        </span>
        {/* Tags */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.tag === 'Hot' && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded text-white" style={{ background: '#E53935' }}>
              🔥 Hot
            </span>
          )}
          {product.tag === 'New' && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded text-white" style={{ background: '#00897B' }}>
              New
            </span>
          )}
          {product.tag === 'Sale' && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded text-white" style={{ background: '#F57C00' }}>
              Sale
            </span>
          )}
          {showBadge && disc > 0 && !product.tag && (
            <span className="discount-badge">-{disc}%</span>
          )}
        </div>
        {showBadge && product.tag && (
          <span className="absolute top-2 right-2 discount-badge">-{disc}%</span>
        )}
        {/* Wishlist */}
        <button
          className="heart-btn absolute bottom-2 right-2 w-7 h-7 bg-white rounded-full shadow flex items-center justify-center transition-opacity opacity-0 group-hover:opacity-100"
          style={{ color: favorited ? '#E53935' : '#9CA3AF' }}
          onClick={(e) => { e.stopPropagation(); toggleFavorite(product.id); }}
        >
          <Heart size={14} fill={favorited ? 'currentColor' : 'none'} />
        </button>
      </div>

      {/* Body */}
      <div className="p-3">
        <p className="text-sm text-gray-800 font-medium line-clamp-2 leading-tight mb-1 h-10">{product.name}</p>
        <p className="text-xs text-gray-400 line-clamp-1 mb-2">{product.description}</p>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          <div className="flex text-yellow-400">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={11}
                fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'}
                strokeWidth={1.5}
              />
            ))}
          </div>
          <span className="text-[10px] text-gray-400">({product.sold.toLocaleString('vi-VN')} đã bán)</span>
        </div>

        {/* Price */}
        <div className="flex items-end gap-1 mb-3">
          <span className="text-lg font-black" style={{ color: '#F57C00' }}>
            {formatPrice(product.price)}
          </span>
          <del className="text-xs text-gray-400 mb-0.5">{formatPrice(product.originalPrice)}</del>
        </div>

        {/* Button */}
        <button
          className="w-full py-2 rounded-lg text-xs font-bold text-white flex items-center justify-center gap-1 transition-opacity hover:opacity-90 active:scale-95"
          style={{ background: '#F57C00' }}
          onClick={(e) => { e.stopPropagation(); onClick?.(product); }}
        >
          <ShoppingCart size={13} /> Mua ngay
        </button>
      </div>
    </div>
  );
}
