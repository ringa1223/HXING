const quickLinks = ['Trang chủ', 'Thời trang', 'Điện tử', 'Thực phẩm', 'Gia dụng', 'Mẹ & bé'];
const policies = ['Chính sách đổi trả', 'Chính sách bảo hành', 'Chính sách vận chuyển', 'Bảo mật thông tin'];
const socials = [
  { label: 'Facebook', emoji: '📘', href: '#' },
  { label: 'Zalo', emoji: '💬', href: '#' },
  { label: 'YouTube', emoji: '▶️', href: '#' },
  { label: 'TikTok', emoji: '🎵', href: '#' },
];

export default function Footer() {
  return (
    <footer style={{ background: '#0D2B4A' }} className="text-white pt-10 pb-6 px-4 mt-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company info */}
          <div className="lg:col-span-1">
            <div className="mb-3">
              <span className="text-2xl font-black" style={{ color: '#F57C00' }}>FORTUNE</span>
              <span className="text-2xl font-black text-white">LINK</span>
            </div>
            <p className="text-xs text-white/60 mb-4 leading-relaxed">
              CÔNG TY TNHH XUẤT NHẬP KHẨU FORTUNELINK
            </p>
            <div className="space-y-1.5 text-sm text-white/70">
              <p>📍 123 Nguyễn Huệ, Quận 1, TP. Hồ Chí Minh</p>
              <p>📞 <a href="tel:+84901234567" className="hover:text-primary-light transition-colors">0901 234 567</a></p>
              <p>✉️ <a href="mailto:info@fortunelink.vn" className="hover:text-primary-light transition-colors">info@fortunelink.vn</a></p>
              <p className="text-xs text-white/40">MST: 0123456789</p>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-bold text-sm mb-3 uppercase tracking-wider" style={{ color: '#FFB74D' }}>
              Danh mục
            </h4>
            <ul className="space-y-1.5">
              {quickLinks.map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                    › {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Policies */}
          <div>
            <h4 className="font-bold text-sm mb-3 uppercase tracking-wider" style={{ color: '#FFB74D' }}>
              Chính sách
            </h4>
            <ul className="space-y-1.5">
              {policies.map((policy) => (
                <li key={policy}>
                  <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                    › {policy}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social & app */}
          <div>
            <h4 className="font-bold text-sm mb-3 uppercase tracking-wider" style={{ color: '#FFB74D' }}>
              Kết nối với chúng tôi
            </h4>
            <div className="flex flex-wrap gap-2 mb-5">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm text-white/80 hover:text-white transition-colors"
                  style={{ background: 'rgba(255,255,255,0.1)' }}
                >
                  <span>{s.emoji}</span> {s.label}
                </a>
              ))}
            </div>
            <div
              className="rounded-xl p-3 text-center"
              style={{ background: 'rgba(245,124,0,0.2)', border: '1px solid rgba(245,124,0,0.4)' }}
            >
              <p className="text-xs text-white/70 mb-1">📦 Đăng ký nhận ưu đãi</p>
              <div className="flex gap-1">
                <input
                  type="email"
                  placeholder="Email của bạn"
                  className="flex-1 bg-white/10 text-white text-xs rounded px-2 py-1.5 placeholder:text-white/40 border border-white/20 focus:border-primary"
                />
                <button
                  className="px-3 py-1.5 rounded text-xs font-bold text-white transition-opacity hover:opacity-90"
                  style={{ background: '#F57C00' }}
                >
                  Gửi
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/10 pt-5 flex flex-col sm:flex-row justify-between items-center gap-2">
          <p className="text-xs text-white/50">© 2026 FORTUNELINK. All rights reserved.</p>
          <p className="text-xs text-white/50">🔒 Thanh toán bảo mật SSL | Hoàn tiền 100% nếu hàng lỗi</p>
        </div>
      </div>
    </footer>
  );
}
