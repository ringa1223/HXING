const advantages = [
  {
    emoji: '🚚',
    title: 'Giao hàng toàn quốc',
    desc: 'Miễn phí ship đơn từ 299.000đ. Giao trong 2-5 ngày làm việc',
    color: '#E3F2FD',
    accent: '#1565C0',
  },
  {
    emoji: '✅',
    title: 'Hàng chính hãng 100%',
    desc: 'Nhập khẩu trực tiếp, có tem chống hàng giả, cam kết hoàn tiền',
    color: '#E8F5E9',
    accent: '#2E7D32',
  },
  {
    emoji: '🔒',
    title: 'Thanh toán an toàn',
    desc: 'Hỗ trợ COD, chuyển khoản, ví MoMo, ZaloPay và thẻ ngân hàng',
    color: '#FFF3E0',
    accent: '#E65100',
  },
  {
    emoji: '🎧',
    title: 'Hỗ trợ 24/7',
    desc: 'Đội ngũ tư vấn nhiệt tình, xử lý khiếu nại trong 24 giờ',
    color: '#FCE4EC',
    accent: '#C62828',
  },
];

export default function ServiceAdvantages() {
  return (
    <section className="py-6 px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-xl font-black text-gray-900 text-center mb-5">
          Tại sao chọn <span style={{ color: '#F57C00' }}>FORTUNELINK?</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {advantages.map((adv) => (
            <div
              key={adv.title}
              className="rounded-2xl p-5 text-center card-lift shadow-card"
              style={{ background: adv.color }}
            >
              <div className="text-4xl mb-3">{adv.emoji}</div>
              <h3 className="font-black text-base text-gray-900 mb-2" style={{ color: adv.accent }}>
                {adv.title}
              </h3>
              <p className="text-sm text-gray-600 leading-relaxed">{adv.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
