import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  {
    id: 1,
    bg: 'linear-gradient(135deg, #F57C00 0%, #FF8F00 40%, #E65100 100%)',
    badge: '🔥 SIÊU SALE',
    title: 'Siêu sale\ncuối năm 2026',
    subtitle: 'Giảm đến 70% hàng ngàn sản phẩm chất lượng cao',
    cta: 'Mua ngay',
    emoji: '🎁',
    accent: 'rgba(255,255,255,0.15)',
  },
  {
    id: 2,
    bg: 'linear-gradient(135deg, #0D2B4A 0%, #1A3A5C 50%, #0D47A1 100%)',
    badge: '⚡ ĐIỆN TỬ',
    title: 'Điện tử\ngiá sốc',
    subtitle: 'Tai nghe, loa, phụ kiện – giá chỉ từ 75.000đ',
    cta: 'Khám phá',
    emoji: '📱',
    accent: 'rgba(245,124,0,0.2)',
  },
  {
    id: 3,
    bg: 'linear-gradient(135deg, #00695C 0%, #00897B 50%, #26A69A 100%)',
    badge: '🏠 GIA DỤNG',
    title: 'Đồ gia dụng\nưu đãi lớn',
    subtitle: 'Nồi cơm, máy xay, quạt điện – giao hàng toàn quốc',
    cta: 'Xem ngay',
    emoji: '🍚',
    accent: 'rgba(255,255,255,0.12)',
  },
  {
    id: 4,
    bg: 'linear-gradient(135deg, #B71C1C 0%, #C62828 50%, #E53935 100%)',
    badge: '👕 THỜI TRANG',
    title: 'Thời trang hè\nrực rỡ',
    subtitle: 'Áo sơ mi, giày, túi xách – phong cách trẻ trung',
    cta: 'Mua ngay',
    emoji: '👗',
    accent: 'rgba(255,213,79,0.2)',
  },
];

export default function HeroCarousel() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((p) => (p + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const prev = () => setCurrent((p) => (p - 1 + slides.length) % slides.length);
  const next = () => setCurrent((p) => (p + 1) % slides.length);

  return (
    <section id="home" className="relative w-full overflow-hidden" style={{ height: '420px' }}>
      {slides.map((slide, i) => (
        <div
          key={slide.id}
          className={`absolute inset-0 carousel-slide ${i === current ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
          style={{ background: slide.bg }}
        >
          {/* Decorative circles */}
          <div
            className="absolute -right-16 -top-16 w-72 h-72 rounded-full"
            style={{ background: slide.accent }}
          />
          <div
            className="absolute -left-8 -bottom-20 w-56 h-56 rounded-full"
            style={{ background: slide.accent }}
          />

          <div className="relative z-10 h-full max-w-7xl mx-auto px-6 flex items-center">
            <div className="flex-1">
              <span
                className="inline-block text-xs font-bold px-3 py-1 rounded-full mb-4"
                style={{ background: 'rgba(255,255,255,0.25)', color: 'white' }}
              >
                {slide.badge}
              </span>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-3 leading-tight whitespace-pre-line">
                {slide.title}
              </h2>
              <p className="text-white/80 text-base md:text-lg mb-6 max-w-md">
                {slide.subtitle}
              </p>
              <button
                className="px-8 py-3 rounded-full font-bold text-sm transition-transform hover:scale-105 active:scale-95"
                style={{ background: 'white', color: '#F57C00' }}
              >
                {slide.cta} →
              </button>
            </div>
            <div className="hidden md:flex items-center justify-center w-48 h-48 text-9xl">
              {slide.emoji}
            </div>
          </div>
        </div>
      ))}

      {/* Arrows */}
      <button
        onClick={prev}
        className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 backdrop-blur text-white flex items-center justify-center transition-colors"
      >
        <ChevronLeft size={22} />
      </button>
      <button
        onClick={next}
        className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 backdrop-blur text-white flex items-center justify-center transition-colors"
      >
        <ChevronRight size={22} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className="rounded-full transition-all duration-300"
            style={{
              width: i === current ? '24px' : '8px',
              height: '8px',
              background: i === current ? 'white' : 'rgba(255,255,255,0.5)',
            }}
          />
        ))}
      </div>
    </section>
  );
}
