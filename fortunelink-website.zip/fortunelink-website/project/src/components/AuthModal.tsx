import { useState, FormEvent } from 'react';
import { X, Mail, Lock, User, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Props {
  mode: 'login' | 'register';
  onClose: () => void;
  onSuccess?: () => void;
  onSwitchMode: (mode: 'login' | 'register') => void;
}

export default function AuthModal({ mode, onClose, onSuccess, onSwitchMode }: Props) {
  const { signIn, signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    let err: string | null;
    if (mode === 'login') {
      err = await signIn(email, password);
    } else {
      if (password.length < 6) {
        setError('Mật khẩu phải có ít nhất 6 ký tự.');
        setSubmitting(false);
        return;
      }
      err = await signUp(email, password, displayName);
    }
    setSubmitting(false);
    if (err) {
      if (err.includes('already registered') || err.includes('already been registered')) {
        setError('Email này đã được đăng ký. Vui lòng đăng nhập.');
      } else if (err.includes('Invalid login credentials')) {
        setError('Email hoặc mật khẩu không đúng.');
      } else if (err.includes('Email not confirmed')) {
        setError('Email chưa được xác nhận. Kiểm tra hộp thư.');
      } else {
        setError(err);
      }
    } else {
      onSuccess?.();
      onClose();
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal-panel"
        style={{ maxWidth: 440 }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close */}
        <button onClick={onClose} className="modal-close-btn" aria-label="Đóng">
          <X size={20} />
        </button>

        <div className="p-8">
          {/* Logo */}
          <div className="text-center mb-6">
            <span className="text-2xl font-black" style={{ color: '#F57C00' }}>
              FORTUNE<span style={{ color: '#0D2B4A' }}>LINK</span>
            </span>
            <p className="text-gray-500 text-sm mt-1">
              {mode === 'login' ? 'Đăng nhập vào tài khoản' : 'Tạo tài khoản mới'}
            </p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-xl overflow-hidden border border-gray-200 mb-6">
            {(['login', 'register'] as const).map((m) => (
              <button
                key={m}
                onClick={() => { onSwitchMode(m); setError(null); }}
                className="flex-1 py-2.5 text-sm font-semibold transition-colors"
                style={
                  mode === m
                    ? { background: '#F57C00', color: 'white' }
                    : { background: 'white', color: '#6B7280' }
                }
              >
                {m === 'login' ? 'Đăng nhập' : 'Đăng ký'}
              </button>
            ))}
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 mb-4 text-sm">
              <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {mode === 'register' && (
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Họ và tên"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full border border-gray-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:border-orange-400 outline-none transition-colors"
                  required
                />
              </div>
            )}
            <div className="relative">
              <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:border-orange-400 outline-none transition-colors"
                required
              />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type={showPw ? 'text' : 'password'}
                placeholder="Mật khẩu"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-gray-200 rounded-xl py-3 pl-10 pr-10 text-sm focus:border-orange-400 outline-none transition-colors"
                required
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all hover:opacity-90 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg, #F57C00, #FF8C00)' }}
            >
              {submitting
                ? 'Đang xử lý...'
                : mode === 'login' ? 'Đăng nhập' : 'Tạo tài khoản'}
            </button>
          </form>

          <p className="text-center text-xs text-gray-400 mt-5">
            {mode === 'login' ? 'Chưa có tài khoản? ' : 'Đã có tài khoản? '}
            <button
              onClick={() => onSwitchMode(mode === 'login' ? 'register' : 'login')}
              className="font-semibold underline"
              style={{ color: '#F57C00' }}
            >
              {mode === 'login' ? 'Đăng ký ngay' : 'Đăng nhập'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
