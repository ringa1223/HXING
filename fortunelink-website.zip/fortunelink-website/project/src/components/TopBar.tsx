export default function TopBar() {
  return (
    <div className="bg-navy text-white text-xs py-2 px-4">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-1">
        <span className="font-medium tracking-wide">
          🎉 Chào mừng đến với <strong>FORTUNELINK</strong> — Nhập khẩu chính hãng, giá tốt nhất!
        </span>
        <div className="flex items-center gap-4">
          <a href="tel:+84901234567" className="hover:text-primary-light transition-colors flex items-center gap-1">
            📞 0901 234 567
          </a>
          <a href="mailto:info@fortunelink.vn" className="hover:text-primary-light transition-colors hidden sm:flex items-center gap-1">
            ✉️ info@fortunelink.vn
          </a>
          <div className="flex gap-2 border-l border-white/30 pl-3">
            <button className="font-bold text-primary-light">VI</button>
            <span className="text-white/40">/</span>
            <button className="hover:text-primary-light transition-colors">EN</button>
          </div>
        </div>
      </div>
    </div>
  );
}
