import { brands } from '../data/products';

export default function BrandShowcase() {
  return (
    <section className="py-6 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-2xl shadow-card p-6">
          <h2 className="text-xl font-black text-gray-900 text-center mb-6">
            Thương hiệu <span style={{ color: '#F57C00' }}>đối tác</span>
          </h2>
          <div className="grid grid-cols-4 sm:grid-cols-8 gap-4">
            {brands.map((brand) => (
              <div
                key={brand.name}
                className="brand-logo flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-gray-50 hover:bg-orange-50 cursor-pointer transition-colors"
              >
                <span className="text-3xl">{brand.emoji}</span>
                <span className="text-xs font-semibold text-gray-600 text-center leading-tight">{brand.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
