import { useState, useEffect } from 'react';
import { flashSaleProducts, formatPrice, discountPercent } from '../data/products';

function getTargetTime(): Date {
  const now = new Date();
  const target = new Date(now);
  target.setHours(now.getHours() + 8, 0, 0, 0);
  return target;
}

function CountdownBlock({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col items-center">
      <div
        className="w-10 h-10 rounded-lg flex items-center justify-center font-black text-lg text-white"
        style={{ background: '#0D2B4A' }}
      >
        {String(value).padStart(2, '0')}
      </div>
      <span className="text-[9px] text-white/70 mt-0.5 font-medium uppercase">{label}</span>
    </div>
  );
}

export default function FlashSale() {
  const [target] = useState(getTargetTime);
  const [timeLeft, setTimeLeft] = useState({ h: 0, m: 0, s: 0 });

  useEffect(() => {
    const tick = () => {
      const diff = target.getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft({ h: 0, m: 0, s: 0 });
        return;
      }
      setTimeLeft({
        h: Math.floor(diff / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      });
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [target]);

  return (
    <section className="py-6 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="rounded-2xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #F57C00, #FF8F00)' }}>
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between px-5 py-4 gap-3">
            <div className="flex items-center gap-3">
              <span className="text-2xl badge-pulse">🔥</span>
              <div>
                <h2 className="text-xl font-black text-white tracking-tight">Giờ vàng săn sale</h2>
                <p className="text-white/75 text-xs">Ưu đãi giảm sốc, số lượng có hạn!</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-white/80 text-xs font-medium">Kết thúc sau:</span>
              <div className="flex items-center gap-1">
                <CountdownBlock value={timeLeft.h} label="Giờ" />
                <span className="text-white font-black text-lg mb-3">:</span>
                <CountdownBlock value={timeLeft.m} label="Phút" />
                <span className="text-white font-black text-lg mb-3">:</span>
                <CountdownBlock value={timeLeft.s} label="Giây" />
              </div>
            </div>
          </div>

          {/* Products */}
          <div className="bg-white/10 backdrop-blur-sm px-4 pb-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {flashSaleProducts.map((p) => {
                const disc = discountPercent(p.price, p.originalPrice);
                return (
                  <div
                    key={p.id}
                    className="bg-white rounded-xl p-3 flex flex-col card-lift cursor-pointer"
                  >
                    {/* Image area */}
                    <div
                      className="rounded-lg h-24 flex items-center justify-center mb-2 relative overflow-hidden"
                      style={{ background: p.bgColor }}
                    >
                      <img
                        src={p.image}
                        alt={p.name}
                        className="h-full w-full object-cover"
                        style={{ aspectRatio: '1/1' }}
                        onError={(e) => {
                          const t = e.currentTarget;
                          t.style.display = 'none';
                          const fallback = t.nextElementSibling as HTMLElement | null;
                          if (fallback) fallback.style.display = 'flex';
                        }}
                      />
                      <span className="text-5xl hidden items-center justify-center absolute inset-0">{p.emoji}</span>
                      <span className="absolute top-1.5 left-1.5 discount-badge">-{disc}%</span>
                    </div>
                    {/* Info */}
                    <p className="text-xs text-gray-800 font-medium line-clamp-2 mb-1 leading-tight flex-1">{p.name}</p>
                    <p className="text-base font-black" style={{ color: '#E53935' }}>
                      {formatPrice(p.price)}
                    </p>
                    <del className="text-xs text-gray-400">{formatPrice(p.originalPrice)}</del>
                    {/* Progress */}
                    <div className="mt-2">
                      <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${p.soldPercent}%`, background: '#F57C00' }}
                        />
                      </div>
                      <p className="text-[10px] text-gray-500 mt-0.5">Đã bán {p.soldPercent}%</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
