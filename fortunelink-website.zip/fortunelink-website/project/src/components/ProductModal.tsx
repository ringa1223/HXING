import { useState, useEffect, useCallback } from 'react';
import { X, Star, ShoppingCart, Heart, Minus, Plus, CheckCircle, LogIn } from 'lucide-react';
import { Product, formatPrice, discountPercent } from '../data/products';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useFavorites } from '../contexts/FavoritesContext';

interface Props {
  product: Product | null;
  onClose: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export default function ProductModal({ product, onClose, onOpenAuth }: Props) {
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { isFavorited, toggleFavorite } = useFavorites();

  const [qty, setQty] = useState(1);
  const [toast, setToast] = useState<'cart' | 'auth' | null>(null);

  useEffect(() => {
    if (product) {
      setQty(1);
      setToast(null);
    }
  }, [product?.id]);

  const handleKey = useCallback(
    (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); },
    [onClose]
  );

  useEffect(() => {
    if (!product) return;
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [product, handleKey]);

  if (!product) return null;

  const disc = discountPercent(product.price, product.originalPrice);
  const favorited = isFavorited(product.id);

  const handleBuy = async () => {
    if (!user) {
      setToast('auth');
      setTimeout(() => setToast(null), 3000);
      return;
    }
    await addToCart(product.id, qty);
    setToast('cart');
    setTimeout(() => setToast(null), 2500);
  };

  const handleFavorite = () => {
    if (!user) { onOpenAuth('login'); return; }
    toggleFavorite(product.id);
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal-panel"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* Close button */}
        <button onClick={onClose} className="modal-close-btn" aria-label="Đóng">
          <X size={20} />
        </button>

        {/* Toast */}
        {toast === 'cart' && (
          <div className="modal-toast">
            <CheckCircle size={18} />
            <span>Đã thêm {qty} sản phẩm vào giỏ hàng!</span>
          </div>
        )}
        {toast === 'auth' && (
          <div className="modal-toast" style={{ background: '#E53935' }}>
            <LogIn size={18} />
            <span>Vui lòng đăng nhập để mua hàng!</span>
          </div>
        )}

        <div className="modal-body">
          {/* Left: image */}
          <div className="modal-image-col">
            <div className="modal-image-wrap">
              <img
                src={product.image}
                alt={product.name}
                className="modal-image"
                onError={(e) => {
                  const t = e.currentTarget;
                  t.style.display = 'none';
                  const fb = t.nextElementSibling as HTMLElement | null;
                  if (fb) fb.style.display = 'flex';
                }}
              />
              <span
                className="text-8xl absolute inset-0 hidden items-center justify-center"
                style={{ background: product.bgColor }}
              >
                {product.emoji}
              </span>
            </div>
            {disc > 0 && <div className="modal-disc-badge">-{disc}%</div>}
          </div>

          {/* Right: details */}
          <div className="modal-info-col">
            {product.tag && (
              <span
                className="inline-block text-xs font-bold px-2 py-0.5 rounded mb-2 text-white"
                style={{ background: product.tag === 'Hot' ? '#E53935' : product.tag === 'New' ? '#00897B' : '#F57C00' }}
              >
                {product.tag === 'Hot' ? '🔥 Hot' : product.tag}
              </span>
            )}

            <h2 className="text-2xl font-black text-gray-900 leading-tight mb-3">{product.name}</h2>

            <div className="flex items-center gap-3 mb-4">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className="text-yellow-400"
                    fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'}
                    strokeWidth={1.5}
                  />
                ))}
                <span className="text-sm font-semibold text-gray-700 ml-1">{product.rating}</span>
              </div>
              <span className="text-sm text-gray-400">|</span>
              <span className="text-sm text-gray-500">{product.sold.toLocaleString('vi-VN')} đã bán</span>
            </div>

            {/* Price */}
            <div
              className="rounded-xl p-4 mb-4"
              style={{ background: 'linear-gradient(135deg, #FFF3E0, #FFF8E1)' }}
            >
              <div className="flex items-end gap-3 flex-wrap">
                <span className="text-3xl font-black" style={{ color: '#F57C00' }}>
                  {formatPrice(product.price)}
                </span>
                <del className="text-base text-gray-400 mb-1">{formatPrice(product.originalPrice)}</del>
                <span
                  className="text-sm font-bold px-2 py-0.5 rounded text-white mb-1"
                  style={{ background: '#E53935' }}
                >
                  -{disc}%
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Tiết kiệm: {formatPrice(product.originalPrice - product.price)}
              </p>
            </div>

            <p className="text-sm text-gray-600 leading-relaxed mb-4">{product.description}</p>

            {/* Specs */}
            <div className="rounded-xl p-4 mb-5" style={{ background: '#F5F7FA' }}>
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">Thông số kỹ thuật</p>
              <div className="grid grid-cols-1 gap-2">
                {Object.entries(product.specs).map(([key, val]) => (
                  <div key={key} className="flex items-start gap-2 text-sm">
                    <span className="text-gray-500 w-28 flex-shrink-0 font-medium">{key}:</span>
                    <span className="text-gray-800 font-medium">{val}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-4 mb-5">
              <span className="text-sm font-semibold text-gray-700">Số lượng:</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="w-9 h-9 rounded-full border-2 border-gray-200 flex items-center justify-center text-gray-600 hover:border-orange-400 hover:text-orange-500 transition-colors"
                >
                  <Minus size={14} />
                </button>
                <span className="w-12 h-9 border-2 border-gray-200 rounded-lg flex items-center justify-center text-base font-bold text-gray-900">
                  {qty}
                </span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="w-9 h-9 rounded-full border-2 border-gray-200 flex items-center justify-center text-gray-600 hover:border-orange-400 hover:text-orange-500 transition-colors"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>

            {/* Auth hint */}
            {!user && (
              <p className="text-xs text-gray-400 mb-3 flex items-center gap-1">
                <LogIn size={13} />
                <button
                  onClick={() => { onClose(); onOpenAuth('login'); }}
                  className="underline"
                  style={{ color: '#F57C00' }}
                >
                  Đăng nhập
                </button>
                {' '}để mua hàng và lưu yêu thích.
              </p>
            )}

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={handleBuy}
                className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-3xl text-base font-bold text-white transition-all hover:opacity-90 active:scale-95"
                style={{ background: 'linear-gradient(135deg, #F57C00, #FF8C00)' }}
              >
                <ShoppingCart size={18} />
                {user ? 'Thêm vào giỏ' : 'Đăng nhập để mua'}
              </button>
              <button
                onClick={handleFavorite}
                className="w-14 h-14 rounded-3xl border-2 flex items-center justify-center transition-all hover:scale-105 active:scale-95"
                style={{
                  borderColor: favorited ? '#E53935' : '#E5E7EB',
                  background: favorited ? '#FFF1F0' : 'white',
                  color: favorited ? '#E53935' : '#9CA3AF',
                }}
                aria-label="Yêu thích"
              >
                <Heart size={20} fill={favorited ? 'currentColor' : 'none'} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
