import { useEffect } from 'react';
import { X, ShoppingCart, Trash2, Plus, Minus, Package } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { formatPrice } from '../data/products';

interface Props {
  open: boolean;
  onClose: () => void;
  onOpenAuth: () => void;
}

export default function CartDrawer({ open, onClose, onOpenAuth }: Props) {
  const { cartItems, cartCount, cartTotal, loading, removeFromCart, updateQuantity } = useCart();

  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-black/50"
        onClick={onClose}
        style={{ animation: 'modalBackdropIn 0.25s ease' }}
      />

      {/* Drawer */}
      <div
        className="fixed top-0 right-0 h-full w-full max-w-sm bg-white z-50 flex flex-col shadow-2xl"
        style={{ animation: 'cartDrawerIn 0.3s ease' }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-4 border-b"
          style={{ background: 'linear-gradient(135deg, #F57C00, #FF8C00)' }}
        >
          <div className="flex items-center gap-2 text-white">
            <ShoppingCart size={20} />
            <span className="font-bold text-lg">Giỏ hàng</span>
            {cartCount > 0 && (
              <span className="bg-white/30 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                {cartCount}
              </span>
            )}
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
            <X size={22} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {loading ? (
            <div className="flex items-center justify-center h-32 text-gray-400 text-sm">
              Đang tải...
            </div>
          ) : cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
              <Package size={40} strokeWidth={1} />
              <p className="text-sm font-medium">Giỏ hàng trống</p>
              <button
                onClick={() => { onClose(); onOpenAuth(); }}
                className="text-xs underline"
                style={{ color: '#F57C00' }}
              >
                Đăng nhập để xem giỏ hàng
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 bg-gray-50 rounded-xl p-3"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-800 line-clamp-2 leading-tight mb-1">
                      {item.product.name}
                    </p>
                    <p className="text-base font-black" style={{ color: '#F57C00' }}>
                      {formatPrice(item.product.price)}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-7 h-7 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:border-orange-400 hover:text-orange-500 transition-colors"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-7 h-7 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:border-orange-400 hover:text-orange-500 transition-colors"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {cartItems.length > 0 && (
          <div className="border-t p-4 bg-white">
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm text-gray-500">Tổng cộng ({cartCount} sản phẩm)</span>
              <span className="text-xl font-black" style={{ color: '#F57C00' }}>
                {formatPrice(cartTotal)}
              </span>
            </div>
            <p className="text-xs text-gray-400 mb-3">Chưa bao gồm phí vận chuyển</p>
            <button
              className="w-full py-3.5 rounded-xl text-white font-bold text-sm transition-all hover:opacity-90 active:scale-95"
              style={{ background: 'linear-gradient(135deg, #F57C00, #FF8C00)' }}
              onClick={() => alert('Tính năng thanh toán sẽ sớm ra mắt!')}
            >
              Tiến hành thanh toán →
            </button>
          </div>
        )}
      </div>
    </>
  );
}
