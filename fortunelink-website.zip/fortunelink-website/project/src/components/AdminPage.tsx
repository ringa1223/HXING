import { useEffect, useState } from 'react';
import { ArrowLeft, Users, ShoppingBag, Heart, Package, Shield, Crown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { products, formatPrice } from '../data/products';

interface AdminStats {
  total_users: number;
  total_cart_entries: number;
  total_cart_qty: number;
  total_favorites: number;
}

interface ProfileRow {
  user_id: string;
  display_name: string;
  email: string;
  is_admin: boolean;
  created_at: string;
}

interface CartRow {
  id: string;
  user_id: string;
  product_id: number;
  quantity: number;
  created_at: string;
}

interface Props {
  onBack: () => void;
}

export default function AdminPage({ onBack }: Props) {
  const { user, profile, isAdmin } = useAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [allProfiles, setAllProfiles] = useState<ProfileRow[]>([]);
  const [allCarts, setAllCarts] = useState<CartRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [makingAdmin, setMakingAdmin] = useState(false);

  useEffect(() => {
    loadData();
  }, [isAdmin]);

  const loadData = async () => {
    setLoading(true);
    const [statsRes, profilesRes, cartsRes] = await Promise.all([
      supabase.rpc('get_admin_stats'),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('carts').select('*').order('created_at', { ascending: false }).limit(20),
    ]);
    setStats(statsRes.data);
    setAllProfiles(profilesRes.data ?? []);
    setAllCarts(cartsRes.data ?? []);
    setLoading(false);
  };

  const handleBecomeAdmin = async () => {
    if (!user) return;
    setMakingAdmin(true);
    await supabase
      .from('profiles')
      .update({ is_admin: true })
      .eq('user_id', user.id);
    await loadData();
    setMakingAdmin(false);
    window.location.reload();
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#F5F7FA' }}>
        <div className="text-center">
          <Shield size={48} className="text-gray-300 mx-auto mb-4" />
          <p className="text-gray-600 font-medium mb-4">Vui lòng đăng nhập để truy cập trang quản trị.</p>
          <button onClick={onBack} className="text-orange-500 underline text-sm">Về trang chủ</button>
        </div>
      </div>
    );
  }

  const statCards = [
    { label: 'Người dùng', value: stats?.total_users ?? 0, icon: Users, color: '#1565C0' },
    { label: 'Mục giỏ hàng', value: stats?.total_cart_entries ?? 0, icon: ShoppingBag, color: '#F57C00' },
    { label: 'Tổng SL giỏ', value: stats?.total_cart_qty ?? 0, icon: Package, color: '#2E7D32' },
    { label: 'Yêu thích', value: stats?.total_favorites ?? 0, icon: Heart, color: '#E53935' },
  ];

  return (
    <div className="min-h-screen" style={{ background: '#F5F7FA' }}>
      {/* Top bar */}
      <div
        className="sticky top-0 z-40 px-6 py-4 flex items-center gap-4 shadow-sm"
        style={{ background: 'linear-gradient(135deg, #0D2B4A, #1A3A5C)' }}
      >
        <button onClick={onBack} className="text-white/70 hover:text-white transition-colors">
          <ArrowLeft size={22} />
        </button>
        <div className="flex items-center gap-2">
          <Crown size={20} className="text-yellow-400" />
          <span className="text-white font-black text-lg">Admin Dashboard</span>
        </div>
        <span className="ml-auto text-white/60 text-xs">
          {profile?.display_name || profile?.email}
        </span>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Demo notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-5 py-3 mb-6 flex items-start gap-3 text-sm text-amber-800">
          <Shield size={18} className="flex-shrink-0 mt-0.5" />
          <div>
            <strong>Demo mode:</strong> Đây là trang quản trị dùng cho mục đích trình diễn. Dữ liệu hiển thị phụ thuộc vào quyền admin của tài khoản hiện tại.
            {!isAdmin && (
              <span>
                {' '}Bạn chưa có quyền admin.{' '}
                <button
                  onClick={handleBecomeAdmin}
                  disabled={makingAdmin}
                  className="font-bold underline"
                >
                  {makingAdmin ? 'Đang xử lý...' : 'Cấp quyền Admin (Demo)'}
                </button>
              </span>
            )}
          </div>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statCards.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="bg-white rounded-2xl p-5 shadow-sm flex flex-col gap-2">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: color + '18' }}
              >
                <Icon size={20} style={{ color }} />
              </div>
              <p className="text-2xl font-black text-gray-900">
                {loading ? '—' : value.toLocaleString('vi-VN')}
              </p>
              <p className="text-xs text-gray-500 font-medium">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Users list */}
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b flex items-center gap-2">
              <Users size={18} className="text-blue-600" />
              <h3 className="font-black text-gray-900">Người dùng ({allProfiles.length})</h3>
            </div>
            {loading ? (
              <div className="p-5 text-center text-gray-400 text-sm">Đang tải...</div>
            ) : allProfiles.length === 0 ? (
              <div className="p-5 text-center text-gray-400 text-sm">Chưa có dữ liệu (yêu cầu quyền admin)</div>
            ) : (
              <div className="divide-y max-h-72 overflow-y-auto">
                {allProfiles.map((p) => (
                  <div key={p.user_id} className="flex items-center gap-3 px-5 py-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                      style={{ background: p.is_admin ? '#F57C00' : '#0D2B4A' }}
                    >
                      {(p.display_name || p.email || '?').charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-800 truncate">{p.display_name || '—'}</p>
                      <p className="text-xs text-gray-400 truncate">{p.email}</p>
                    </div>
                    {p.is_admin && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white bg-orange-500">
                        Admin
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent cart activity */}
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b flex items-center gap-2">
              <ShoppingBag size={18} className="text-orange-500" />
              <h3 className="font-black text-gray-900">Hoạt động giỏ hàng (20 gần nhất)</h3>
            </div>
            {loading ? (
              <div className="p-5 text-center text-gray-400 text-sm">Đang tải...</div>
            ) : allCarts.length === 0 ? (
              <div className="p-5 text-center text-gray-400 text-sm">Chưa có dữ liệu (yêu cầu quyền admin)</div>
            ) : (
              <div className="divide-y max-h-72 overflow-y-auto">
                {allCarts.map((c) => {
                  const prod = products.find((p) => p.id === c.product_id);
                  const prof = allProfiles.find((p) => p.user_id === c.user_id);
                  return (
                    <div key={c.id} className="flex items-center gap-3 px-5 py-3">
                      {prod && (
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-800 truncate">
                          {prod?.name ?? `Sản phẩm #${c.product_id}`}
                        </p>
                        <p className="text-xs text-gray-400 truncate">
                          {prof?.display_name ?? 'User'} · SL: {c.quantity} · {formatPrice((prod?.price ?? 0) * c.quantity)}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Products table */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b flex items-center gap-2">
            <Package size={18} className="text-green-600" />
            <h3 className="font-black text-gray-900">Tất cả sản phẩm ({products.length})</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left px-5 py-3 text-xs font-bold text-gray-500 uppercase">Sản phẩm</th>
                  <th className="text-left px-5 py-3 text-xs font-bold text-gray-500 uppercase hidden sm:table-cell">Danh mục</th>
                  <th className="text-right px-5 py-3 text-xs font-bold text-gray-500 uppercase">Giá</th>
                  <th className="text-right px-5 py-3 text-xs font-bold text-gray-500 uppercase hidden md:table-cell">Đã bán</th>
                  <th className="text-right px-5 py-3 text-xs font-bold text-gray-500 uppercase">Tag</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-gray-800 line-clamp-1">{p.name}</p>
                          <p className="text-xs text-gray-400 hidden sm:block line-clamp-1">{p.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-gray-500 hidden sm:table-cell capitalize">{p.category}</td>
                    <td className="px-5 py-3 text-right font-bold" style={{ color: '#F57C00' }}>{formatPrice(p.price)}</td>
                    <td className="px-5 py-3 text-right text-gray-500 hidden md:table-cell">{p.sold.toLocaleString('vi-VN')}</td>
                    <td className="px-5 py-3 text-right">
                      {p.tag ? (
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white"
                          style={{ background: p.tag === 'Hot' ? '#E53935' : p.tag === 'New' ? '#00897B' : '#F57C00' }}
                        >
                          {p.tag}
                        </span>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
