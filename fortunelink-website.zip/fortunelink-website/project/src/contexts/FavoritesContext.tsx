import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

interface FavoritesContextValue {
  favoriteIds: Set<number>;
  loading: boolean;
  toggleFavorite: (productId: number) => Promise<void>;
  isFavorited: (productId: number) => boolean;
}

const FavoritesContext = createContext<FavoritesContextValue | null>(null);

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [favoriteIds, setFavoriteIds] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(false);

  const loadFavorites = useCallback(async () => {
    if (!user) { setFavoriteIds(new Set()); return; }
    setLoading(true);
    const { data } = await supabase
      .from('favorites')
      .select('product_id')
      .eq('user_id', user.id);
    if (data) {
      setFavoriteIds(new Set(data.map((r) => r.product_id as number)));
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadFavorites(); }, [loadFavorites]);

  const toggleFavorite = async (productId: number) => {
    if (!user) return;
    if (favoriteIds.has(productId)) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', productId);
      setFavoriteIds((prev) => { const s = new Set(prev); s.delete(productId); return s; });
    } else {
      await supabase.from('favorites').insert({ product_id: productId });
      setFavoriteIds((prev) => new Set(prev).add(productId));
    }
  };

  const isFavorited = (productId: number) => favoriteIds.has(productId);

  return (
    <FavoritesContext.Provider value={{ favoriteIds, loading, toggleFavorite, isFavorited }}>
      {children}
    </FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error('useFavorites must be used inside FavoritesProvider');
  return ctx;
}
