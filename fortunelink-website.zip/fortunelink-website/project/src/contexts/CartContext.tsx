import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { products, Product } from '../data/products';
import { useAuth } from './AuthContext';

export interface CartItem {
  id: string;
  product_id: number;
  quantity: number;
  product: Product;
}

interface CartContextValue {
  cartItems: CartItem[];
  cartCount: number;
  cartTotal: number;
  loading: boolean;
  addToCart: (productId: number, qty?: number) => Promise<void>;
  removeFromCart: (id: string) => Promise<void>;
  updateQuantity: (id: string, qty: number) => Promise<void>;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);

  const loadCart = useCallback(async () => {
    if (!user) { setCartItems([]); return; }
    setLoading(true);
    const { data } = await supabase
      .from('carts')
      .select('id, product_id, quantity')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true });

    if (data) {
      const enriched = data
        .map((row) => {
          const product = products.find((p) => p.id === row.product_id);
          return product ? { ...row, product } : null;
        })
        .filter(Boolean) as CartItem[];
      setCartItems(enriched);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadCart(); }, [loadCart]);

  const addToCart = async (productId: number, qty = 1) => {
    if (!user) return;
    const existing = cartItems.find((i) => i.product_id === productId);
    if (existing) {
      await supabase
        .from('carts')
        .update({ quantity: existing.quantity + qty })
        .eq('id', existing.id);
    } else {
      await supabase.from('carts').insert({ product_id: productId, quantity: qty });
    }
    await loadCart();
  };

  const removeFromCart = async (id: string) => {
    await supabase.from('carts').delete().eq('id', id);
    await loadCart();
  };

  const updateQuantity = async (id: string, qty: number) => {
    if (qty <= 0) { await removeFromCart(id); return; }
    await supabase.from('carts').update({ quantity: qty }).eq('id', id);
    await loadCart();
  };

  const cartCount = cartItems.reduce((s, i) => s + i.quantity, 0);
  const cartTotal = cartItems.reduce((s, i) => s + i.product.price * i.quantity, 0);

  return (
    <CartContext.Provider value={{ cartItems, cartCount, cartTotal, loading, addToCart, removeFromCart, updateQuantity }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside CartProvider');
  return ctx;
}
