export interface Product {
  id: number;
  category: string;
  name: string;
  description: string;
  price: number;
  originalPrice: number;
  emoji: string;
  bgColor: string;
  image: string;
  specs: Record<string, string>;
  tag?: 'Hot' | 'New' | 'Sale';
  rating: number;
  sold: number;
}

export interface FlashProduct {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  emoji: string;
  bgColor: string;
  soldPercent: number;
  image: string;
}

export const products: Product[] = [
  // Thời trang
  {
    id: 1, category: 'thoi-trang', name: 'Áo sơ mi lụa cao cấp',
    description: 'Chất liệu lụa tự nhiên 100%, mềm mại thoáng mát, form thanh lịch phù hợp công sở và dạo phố.',
    price: 450000, originalPrice: 650000, emoji: '👕', bgColor: '#FFF3E0',
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Lụa tự nhiên 100%', 'Màu sắc': 'Trắng / Đen / Xanh navy', 'Size': 'S / M / L / XL', 'Xuất xứ': 'Việt Nam' },
    tag: 'Hot', rating: 4.8, sold: 1250,
  },
  {
    id: 2, category: 'thoi-trang', name: 'Giày thể thao sneaker',
    description: 'Đế êm chống sốc tối ưu, phù hợp vận động thể thao và đi bộ hàng ngày, trọng lượng nhẹ.',
    price: 890000, originalPrice: 1290000, emoji: '👟', bgColor: '#E8F5E9',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Da lộn + Mesh', 'Màu sắc': 'Trắng / Đen / Xám', 'Size': '36 - 44', 'Xuất xứ': 'Việt Nam' },
    rating: 4.7, sold: 980,
  },
  {
    id: 3, category: 'thoi-trang', name: 'Áo khoác denim unisex',
    description: 'Form rộng thời trang trẻ trung năng động, chất liệu denim 100% cotton bền đẹp, phù hợp mọi giới.',
    price: 650000, originalPrice: 990000, emoji: '🧥', bgColor: '#E3F2FD',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Denim 100% Cotton', 'Màu sắc': 'Xanh đậm / Đen', 'Size': 'S / M / L / XL', 'Xuất xứ': 'Việt Nam' },
    tag: 'New', rating: 4.6, sold: 560,
  },
  {
    id: 4, category: 'thoi-trang', name: 'Quần jean slim fit',
    description: 'Co giãn 4 chiều thoải mái cả ngày dài, form ôm vừa phải phù hợp nhiều dáng người.',
    price: 380000, originalPrice: 520000, emoji: '👖', bgColor: '#EDE7F6',
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Cotton co giãn', 'Màu sắc': 'Xanh / Đen', 'Size': '28 - 38', 'Xuất xứ': 'Việt Nam' },
    rating: 4.5, sold: 2100,
  },
  {
    id: 5, category: 'thoi-trang', name: 'Đầm maxi hoa nhí',
    description: 'Dáng xòe nhẹ nhàng, nữ tính thanh lịch, chất vải mát mịn mềm mại, phù hợp đi chơi dạo phố.',
    price: 420000, originalPrice: 650000, emoji: '👗', bgColor: '#FCE4EC',
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Polyester cao cấp', 'Màu sắc': 'Hoa nhí nhiều màu', 'Size': 'S / M / L', 'Xuất xứ': 'Việt Nam' },
    tag: 'Hot', rating: 4.9, sold: 870,
  },
  {
    id: 6, category: 'thoi-trang', name: 'Túi xách da PU cao cấp',
    description: 'Sang trọng, nhiều ngăn tiện dụng, chất da PU cao cấp bền đẹp, phù hợp đi làm và dạo phố.',
    price: 350000, originalPrice: 550000, emoji: '👜', bgColor: '#FFF8E1',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Da PU cao cấp', 'Màu sắc': 'Đen / Nâu / Be', 'Kích thước': '30 × 20 × 12 cm', 'Xuất xứ': 'Việt Nam' },
    rating: 4.4, sold: 430,
  },
  {
    id: 7, category: 'thoi-trang', name: 'Mũ lưỡi trai thể thao',
    description: 'Chống tia UV hiệu quả, điều chỉnh kích cỡ linh hoạt, chất liệu cotton thoáng khí dễ chịu.',
    price: 120000, originalPrice: 200000, emoji: '🧢', bgColor: '#E0F7FA',
    image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Cotton thoáng khí', 'Màu sắc': 'Đen / Trắng / Xanh', 'Size': 'One size (điều chỉnh)', 'Xuất xứ': 'Việt Nam' },
    rating: 4.3, sold: 1800,
  },
  {
    id: 8, category: 'thoi-trang', name: 'Balo thời trang 20L',
    description: 'Chống thấm nước xuất sắc, ngăn laptop 14 inch riêng biệt, nhiều túi tiện lợi, thiết kế thời trang.',
    price: 480000, originalPrice: 700000, emoji: '🎒', bgColor: '#F3E5F5',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Polyester chống thấm', 'Màu sắc': 'Đen / Xám / Xanh', 'Dung tích': '20L', 'Xuất xứ': 'Việt Nam' },
    tag: 'New', rating: 4.6, sold: 720,
  },

  // Điện tử
  {
    id: 9, category: 'dien-tu', name: 'Tai nghe Bluetooth 5.0 ANC',
    description: 'Chống ồn chủ động ANC đỉnh cao, bass sâu treble rõ ràng, pin 30h, kết nối đa thiết bị ổn định.',
    price: 450000, originalPrice: 790000, emoji: '🎧', bgColor: '#E3F2FD',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    specs: { 'Kết nối': 'Bluetooth 5.0', 'Pin': '30h (ANC bật)', 'Màu sắc': 'Đen / Trắng', 'Trọng lượng': '250g' },
    tag: 'Hot', rating: 4.7, sold: 3200,
  },
  {
    id: 10, category: 'dien-tu', name: 'Sạc dự phòng 20000mAh',
    description: 'Sạc nhanh 22.5W mạnh mẽ, 3 cổng sạc đồng thời, thiết kế siêu mỏng, an toàn tuyệt đối.',
    price: 280000, originalPrice: 450000, emoji: '🔋', bgColor: '#E8F5E9',
    image: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&h=400&fit=crop',
    specs: { 'Dung lượng': '20000mAh', 'Cổng ra': 'USB-C × 2 + USB-A', 'Sạc nhanh': '22.5W', 'Màu sắc': 'Đen / Trắng' },
    rating: 4.6, sold: 1800,
  },
  {
    id: 11, category: 'dien-tu', name: 'Chuột không dây silent',
    description: 'Click êm ái không tiếng ồn, DPI 1600 chính xác, pin AA dùng ~12 tháng, kết nối 2.4G USB nano.',
    price: 195000, originalPrice: 320000, emoji: '🖱️', bgColor: '#F3E5F5',
    image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&h=400&fit=crop',
    specs: { 'Kết nối': '2.4G USB nano', 'DPI': '1600', 'Pin': '1 × AA (~12 tháng)', 'Màu sắc': 'Đen / Trắng / Hồng' },
    rating: 4.5, sold: 950,
  },
  {
    id: 12, category: 'dien-tu', name: 'Loa Bluetooth mini IPX7',
    description: 'Chống nước IPX7 hoàn toàn, âm thanh 360° stereo, kết đôi 2 loa cùng lúc, pin 10h liên tục.',
    price: 350000, originalPrice: 580000, emoji: '🔊', bgColor: '#FFF3E0',
    image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop',
    specs: { 'Kết nối': 'Bluetooth 5.0', 'Pin': '10h', 'Chống nước': 'IPX7', 'Màu sắc': 'Đen / Xanh / Đỏ' },
    tag: 'Hot', rating: 4.8, sold: 2600,
  },
  {
    id: 13, category: 'dien-tu', name: 'Cáp sạc nhanh 60W Type-C',
    description: 'Lõi nylon bện bền chắc, dài 1.2m linh hoạt, hỗ trợ sạc nhanh 60W PD, chống đứt gãy tại đầu cắm.',
    price: 75000, originalPrice: 120000, emoji: '⚡', bgColor: '#FFF8E1',
    image: 'https://images.unsplash.com/photo-1601524909162-ae8725290836?w=400&h=400&fit=crop',
    specs: { 'Chiều dài': '1.2m', 'Công suất': '60W PD', 'Chuẩn': 'Type-C to Type-C', 'Màu sắc': 'Đen / Trắng / Xanh' },
    rating: 4.3, sold: 5100,
  },
  {
    id: 14, category: 'dien-tu', name: 'Giá đỡ điện thoại từ tính',
    description: 'Xoay 360° linh hoạt, nam châm siêu mạnh giữ chắc, gắn được trên khe gió và kính xe, lắp đặt dễ dàng.',
    price: 85000, originalPrice: 149000, emoji: '📱', bgColor: '#FCE4EC',
    image: 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400&h=400&fit=crop',
    specs: { 'Chất liệu': 'Nhựa ABS + Nam châm', 'Xoay': '360°', 'Gắn': 'Khe gió / Kính', 'Màu sắc': 'Đen' },
    rating: 4.4, sold: 4300,
  },
  {
    id: 15, category: 'dien-tu', name: 'Webcam HD 1080P có mic',
    description: 'Độ phân giải Full HD 1080P sắc nét, góc rộng 110° bao quát, tự động cân bằng sáng, mic tích hợp.',
    price: 290000, originalPrice: 489000, emoji: '📷', bgColor: '#E0F2F1',
    image: 'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=400&h=400&fit=crop',
    specs: { 'Độ phân giải': '1080P Full HD', 'Góc nhìn': '110°', 'Kết nối': 'USB 2.0', 'Micro': 'Tích hợp' },
    tag: 'New', rating: 4.5, sold: 680,
  },
  {
    id: 16, category: 'dien-tu', name: 'Bàn phím cơ compact 75%',
    description: 'RGB backlit 16 triệu màu, switch Blue/Red/Brown tùy chọn, layout 75% nhỏ gọn, kết nối USB-C.',
    price: 520000, originalPrice: 850000, emoji: '⌨️', bgColor: '#E8EAF6',
    image: 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=400&h=400&fit=crop',
    specs: { 'Kết nối': 'USB-C có dây', 'Switch': 'Blue / Red / Brown', 'Đèn LED': 'RGB 16 triệu màu', 'Layout': '75% compact' },
    rating: 4.7, sold: 1100,
  },

  // Thực phẩm
  {
    id: 17, category: 'thuc-pham', name: 'Cà phê xay Arabica Đà Lạt',
    description: 'Rang mộc truyền thống giữ trọn hương vị, 100% hạt Arabica cao nguyên Đà Lạt, hương thơm đậm đà.',
    price: 120000, originalPrice: 180000, emoji: '☕', bgColor: '#EFEBE9',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&h=400&fit=crop',
    specs: { 'Loại': 'Arabica 100%', 'Trọng lượng': '500g', 'Rang': 'Rang mộc truyền thống', 'Xuất xứ': 'Đà Lạt, Việt Nam' },
    tag: 'Hot', rating: 4.9, sold: 3800,
  },
  {
    id: 18, category: 'thuc-pham', name: 'Dầu ăn thực vật 1L',
    description: 'Không cholesterol bảo vệ tim mạch, bổ sung vitamin E tự nhiên, tinh luyện cao cấp tốt cho sức khỏe.',
    price: 55000, originalPrice: 75000, emoji: '🫙', bgColor: '#FFF8E1',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
    specs: { 'Dung tích': '1L', 'Thành phần': 'Dầu thực vật tinh luyện', 'Vitamin E': 'Bổ sung', 'Không': 'Cholesterol' },
    rating: 4.5, sold: 6200,
  },
  {
    id: 19, category: 'thuc-pham', name: 'Hạt dinh dưỡng hỗn hợp 300g',
    description: 'Combo hạnh nhân, óc chó, hạt điều rang muối vàng ươm, giàu omega-3, protein, tốt cho não bộ.',
    price: 180000, originalPrice: 250000, emoji: '🥜', bgColor: '#E8F5E9',
    image: 'https://images.unsplash.com/photo-1548690312-e3b507d8c110?w=400&h=400&fit=crop',
    specs: { 'Trọng lượng': '300g', 'Thành phần': 'Hạnh nhân / Óc chó / Hạt điều', 'Giàu': 'Omega-3 / Protein', 'Bảo quản': 'Túi kín khí' },
    rating: 4.7, sold: 1900,
  },
  {
    id: 20, category: 'thuc-pham', name: 'Mật ong rừng nguyên chất 500g',
    description: 'Thu hoạch tự nhiên từ rừng Tây Nguyên, 100% nguyên chất không pha chế, không đường hóa học.',
    price: 150000, originalPrice: 229000, emoji: '🍯', bgColor: '#FFF3E0',
    image: 'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=400&h=400&fit=crop',
    specs: { 'Trọng lượng': '500g', 'Loại': 'Mật ong rừng', 'Nguyên chất': '100%', 'Xuất xứ': 'Tây Nguyên, Việt Nam' },
    rating: 4.8, sold: 2400,
  },
  {
    id: 21, category: 'thuc-pham', name: 'Trà xanh Thái Nguyên 500g',
    description: 'Búp tươi đặc sản vùng trà Thái Nguyên, hương thơm thanh mát dịu nhẹ, đóng gói hút chân không.',
    price: 95000, originalPrice: 140000, emoji: '🍵', bgColor: '#E8F5E9',
    image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?w=400&h=400&fit=crop',
    specs: { 'Trọng lượng': '500g', 'Loại': 'Trà xanh búp', 'Xuất xứ': 'Thái Nguyên', 'Đóng gói': 'Túi kín khí' },
    rating: 4.6, sold: 1100,
  },
  {
    id: 22, category: 'thuc-pham', name: 'Nước ép trái cây organic 330ml',
    description: 'Không đường, không chất bảo quản, nguyên liệu organic 100% tươi sạch, tiện lợi mang theo.',
    price: 45000, originalPrice: 65000, emoji: '🥤', bgColor: '#E3F2FD',
    image: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400&h=400&fit=crop',
    specs: { 'Dung tích': '330ml', 'Loại': 'Organic', 'Không đường': '✓', 'Bảo quản': 'Lạnh 0–4°C' },
    rating: 4.5, sold: 2800,
  },

  // Gia dụng
  {
    id: 23, category: 'gia-dung', name: 'Máy xay sinh tố đa năng 1000W',
    description: '6 lưỡi dao inox sắc bén, dung tích 1.5L lớn, 3 cấp tốc độ xay mịn mọi nguyên liệu từ cứng đến mềm.',
    price: 450000, originalPrice: 680000, emoji: '🌀', bgColor: '#FCE4EC',
    image: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=400&h=400&fit=crop',
    specs: { 'Công suất': '1000W', 'Dung tích': '1.5L', 'Lưỡi dao': 'Inox 6 cánh', 'Tốc độ': '3 mức' },
    tag: 'Hot', rating: 4.7, sold: 1400,
  },
  {
    id: 24, category: 'gia-dung', name: 'Nồi cơm điện thông minh 1.8L',
    description: 'Nấu nhiều chế độ thông minh, giữ ấm 24h không khô, lòng nồi chống dính cao cấp, hẹn giờ tiện lợi.',
    price: 380000, originalPrice: 550000, emoji: '🍚', bgColor: '#FFF8E1',
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
    specs: { 'Dung tích': '1.8L', 'Công suất': '700W', 'Chế độ': 'Nấu / Hẹn giờ / Giữ ấm', 'Chống dính': '✓' },
    rating: 4.6, sold: 2200,
  },
  {
    id: 25, category: 'gia-dung', name: 'Quạt tích điện mini USB-C',
    description: 'Pin 8000mAh dung lượng lớn, 3 cấp tốc độ êm ái, sạc USB-C nhanh, dùng được 8-12h liên tục.',
    price: 290000, originalPrice: 420000, emoji: '💨', bgColor: '#E3F2FD',
    image: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=400&fit=crop',
    specs: { 'Pin': '8000mAh', 'Tốc độ': '3 mức', 'Sạc': 'USB-C', 'Thời gian dùng': '8 – 12h' },
    rating: 4.5, sold: 1600,
  },
  {
    id: 26, category: 'gia-dung', name: 'Bàn là hơi nước 2200W',
    description: 'Công suất 2200W mạnh mẽ, mặt đế chống dính chuyên nghiệp, phun hơi nước mạnh, tự điều nhiệt thông minh.',
    price: 320000, originalPrice: 480000, emoji: '🏠', bgColor: '#E8F5E9',
    image: 'https://images.unsplash.com/photo-1604594849809-dfedbc827105?w=400&h=400&fit=crop',
    specs: { 'Công suất': '2200W', 'Chức năng': 'Phun hơi nước', 'Chống dính': '✓', 'Tự điều nhiệt': '✓' },
    rating: 4.4, sold: 890,
  },

  // Mẹ & bé
  {
    id: 27, category: 'me-be', name: 'Bỉm Pampers size M 76 miếng',
    description: 'Thấm hút siêu nhanh trong 3 giây, lớp mềm mại không kích ứng da bé, giữ khô suốt đêm dài.',
    price: 185000, originalPrice: 240000, emoji: '🧷', bgColor: '#FCE4EC',
    image: 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400&h=400&fit=crop',
    specs: { 'Size': 'M (6 – 11kg)', 'Số lượng': '76 miếng', 'Thương hiệu': 'Pampers', 'Không kích ứng': '✓ Kiểm định da liễu' },
    tag: 'Hot', rating: 4.9, sold: 5600,
  },
  {
    id: 28, category: 'me-be', name: 'Sữa bột Abbott 900g',
    description: 'Bổ sung DHA, ARA, canxi và các vitamin thiết yếu, hỗ trợ phát triển não bộ toàn diện cho trẻ 0-12 tháng.',
    price: 420000, originalPrice: 580000, emoji: '🍼', bgColor: '#E3F2FD',
    image: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=400&h=400&fit=crop',
    specs: { 'Trọng lượng': '900g', 'Độ tuổi': '0 – 12 tháng', 'DHA / ARA': '✓ Bổ sung', 'Thương hiệu': 'Abbott' },
    rating: 4.8, sold: 3100,
  },
  {
    id: 29, category: 'me-be', name: 'Đồ chơi xếp hình 100 mảnh',
    description: 'An toàn tuyệt đối cho trẻ, góc tròn không sắc bén, phát triển tư duy sáng tạo và khả năng tập trung.',
    price: 150000, originalPrice: 220000, emoji: '🧸', bgColor: '#FFF8E1',
    image: 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=400&h=400&fit=crop',
    specs: { 'Số mảnh': '100', 'Chất liệu': 'Nhựa ABS an toàn', 'Độ tuổi': '3+', 'Chứng nhận': 'Kiểm chuẩn an toàn' },
    rating: 4.7, sold: 1800,
  },
  {
    id: 30, category: 'me-be', name: 'Xe đẩy trẻ em cao cấp',
    description: 'Gấp gọn 2 chiều siêu tiện lợi, trọng lượng chỉ 7kg nhẹ nhàng, đạt chứng nhận an toàn 4 sao quốc tế.',
    price: 1850000, originalPrice: 2800000, emoji: '🚼', bgColor: '#E8F5E9',
    image: 'https://images.unsplash.com/photo-1491013516836-7db643ee125a?w=400&h=400&fit=crop',
    specs: { 'Trọng lượng': '7kg', 'Gấp gọn': '2 chiều', 'An toàn': '4 sao quốc tế', 'Độ tuổi': '0 – 3 tuổi' },
    rating: 4.8, sold: 420,
  },
];

export const flashSaleProducts: FlashProduct[] = [
  {
    id: 'fs1', name: 'Tai nghe ANC premium',
    price: 290000, originalPrice: 890000, emoji: '🎧', bgColor: '#E3F2FD', soldPercent: 78,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
  },
  {
    id: 'fs2', name: 'Áo thun unisex oversize',
    price: 89000, originalPrice: 250000, emoji: '👕', bgColor: '#E8F5E9', soldPercent: 92,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
  },
  {
    id: 'fs3', name: 'Dầu dừa organic 250ml',
    price: 65000, originalPrice: 180000, emoji: '🥥', bgColor: '#FFF8E1', soldPercent: 65,
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
  },
  {
    id: 'fs4', name: 'Nồi chiên không dầu 5L',
    price: 590000, originalPrice: 1500000, emoji: '🍳', bgColor: '#FCE4EC', soldPercent: 85,
    image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400&h=400&fit=crop',
  },
  {
    id: 'fs5', name: 'Kem dưỡng da SPF50+',
    price: 85000, originalPrice: 220000, emoji: '✨', bgColor: '#F3E5F5', soldPercent: 71,
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop',
  },
];

export const categoryList = [
  { id: 'thoi-trang', label: 'Thời trang', emoji: '👕' },
  { id: 'dien-tu', label: 'Điện tử', emoji: '📱' },
  { id: 'thuc-pham', label: 'Thực phẩm', emoji: '🛒' },
  { id: 'gia-dung', label: 'Gia dụng', emoji: '🏠' },
  { id: 'me-be', label: 'Mẹ & bé', emoji: '👶' },
  { id: 'the-thao', label: 'Thể thao', emoji: '⚽' },
  { id: 'van-phong', label: 'Văn phòng', emoji: '📎' },
  { id: 'lam-dep', label: 'Làm đẹp', emoji: '💄' },
  { id: 'o-to', label: 'Ô tô xe máy', emoji: '🏍️' },
  { id: 'khac', label: 'Khác', emoji: '📦' },
];

export const brands = [
  { name: 'Samsung', emoji: '📱' },
  { name: 'Apple', emoji: '🍎' },
  { name: 'Unilever', emoji: '🏭' },
  { name: 'Vinamilk', emoji: '🥛' },
  { name: 'Nestlé', emoji: '☕' },
  { name: 'Sony', emoji: '🎵' },
  { name: 'LG', emoji: '📺' },
  { name: 'Panasonic', emoji: '⚡' },
];

export const hotSellingIds = [1, 9, 17, 23, 27, 12];

export const formatPrice = (price: number): string =>
  price.toLocaleString('vi-VN') + 'đ';

export const discountPercent = (price: number, original: number): number =>
  Math.round(((original - price) / original) * 100);
